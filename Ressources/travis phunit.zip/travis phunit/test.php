<?php

use PHPUnit\Framework\TestCase;

class Test extends TestCase
{
    
    public function testInstanceCalculator()
    {
        $this->assertEquals("YES","YES");
    }

   
 }
 
 ?>
