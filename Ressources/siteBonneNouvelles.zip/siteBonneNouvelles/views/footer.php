<footer>
    <strong>Excellente journée qu'aujourd'hui le <?php echo DATEDUJOUR ?></strong>
    :: <?php echo $time; ?>ms pour exécuter le script PHP ::
    <!-- ! adresse email non cryptée : spam possible -->
    <a href="mailto:<?php echo EMAIL ?>"><?php echo EMAIL ?></a>
    <p id="copyright">Mise en page s'inspirant d'<a href="http://www.alsacreations.com/tutoriels/" target="_blank">Alsacréations</a></p>
</footer>
</body>
</html>